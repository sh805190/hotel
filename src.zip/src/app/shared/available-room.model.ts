export class AvailableRoom {
  id: string;
  number: number;
  size: string;
  beds: number;
  cost: number;
  img: string;
  img1: string;
  img2: string;
  img3: string;
  img4: string;
  img5: string;
  img6: string;
  details: string;
}
