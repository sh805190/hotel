export interface Feedback {
    
    title: string;
    name: string;
    rating: string;
    date: string;
    comment: string;
}
