export class BookingHistory {
    ref: string;
	date: string;
    price: number;
    pointsEarned: number;
}
