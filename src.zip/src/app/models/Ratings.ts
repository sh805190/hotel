export class Ratings {
    rate: string;
}
